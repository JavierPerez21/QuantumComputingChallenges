from .lab1 import (
    grade_lab1_ex1,
    grade_lab1_ex2,
    grade_lab1_ex3,
    grade_lab1_ex4,
    grade_lab1_ex5,
    grade_lab1_ex6,
    grade_lab1_ex7,
    grade_lab1_ex8
)

from .lab2 import (
    grade_lab2_ex1,
    grade_lab2_ex2
)

from .lab3 import (
    grade_lab3_ex1,
    grade_lab3_ex2
)
