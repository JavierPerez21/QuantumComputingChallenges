from .exercise1 import *
from .exercise2 import *
from .exercise3 import *
from .exercise4 import *


__all__ = [
    'grade_ex1a', 'grade_ex1b', 'grade_ex1b',
    'grade_ex2a', 'grade_ex2b', 'grade_ex2c',
    'grade_ex3a', 'grade_ex3b', 'grade_ex3c',
    'grade_ex4a', 'grade_ex4b'
]
