#  Hints for solving Challenge Exercises

## Exercise 1 - Toffoli gate

![Ex1 hint](images/ex1_hint.png)

## Exercise 3 - Quantum error correction

[Ex3 hint](https://twitter.com/decodoku/status/1397096214001332225?s=20)

## Exercise 4 - Transmon qubits

![Ex4 hint](images/ex4_hint.png)