## HINTS

### Exercise-3
Our wonderful mentor, Gyeonghun Kim, prepared a guided lecture for **Exercise 3**. 

*Please note, this video does not contain any answers or an easy way to solve the problem. However, we think this would give you good motivation and help you enjoy the beauty of quantum simulation more.*

[English version](https://www.youtube.com/watch?v=ur_uZOF7oAg&list=PLCgqRSfeF6WsHW6zXcE_siqHs7t_dNgIy&index=2)

[Korean version](https://www.youtube.com/watch?v=figrLKAFh_8&list=PLCgqRSfeF6WsHW6zXcE_siqHs7t_dNgIy&index=1&t=14s)

[Lecture slides](https://github.com/GyeonghunKim/IQC-2022-exercise3-guide-lecture)
